
#include <iostream>
#include "GG.cpp"
#include "LL.cpp"
#include "Player.cpp"
using namespace std;


int main()
{
    GG<int> g;
    g.StartMenu();
    
    return 0;
}
